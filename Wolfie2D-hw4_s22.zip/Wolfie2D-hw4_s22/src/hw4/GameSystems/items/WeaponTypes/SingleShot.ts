export default interface SingleShot {
    /** The cooldown time for this weapon */
    cooldown: number;
}