export default class WebGLGameTexture {
	webGLTextureId: number;
	webGLTexture: WebGLTexture;
	imageKey: string;
}